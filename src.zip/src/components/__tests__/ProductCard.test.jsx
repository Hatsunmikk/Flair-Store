import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import ProductCard from "../ProductCard";
import { renderWithProviders } from "../../test-utils";

const product = {
  id: 1,
  title: "Test Product",
  image: "https://via.placeholder.com/150",
  price: 99.99,
  category: "electronics",
};

test("renders product and adds/removes cart/wishlist", () => {
  renderWithProviders(<ProductCard product={product} />, {
    preloadedState: {
      cart: { items: [] },
      wishlist: [],
      notifications: [],
    },
  });

  // Renders info
  expect(screen.getByText(/test product/i)).toBeInTheDocument();
  expect(screen.getByText(/\$99\.99/)).toBeInTheDocument();

  // Add to Cart
  fireEvent.click(screen.getByRole("button", { name: /add to cart/i }));
  expect(screen.getByRole("button", { name: /remove from cart/i })).toBeInTheDocument();

  // Add to Wishlist
  fireEvent.click(screen.getByRole("button", { name: /add to wishlist/i }));
  expect(screen.getByRole("button", { name: /remove from wishlist/i })).toBeInTheDocument();
});
