import React from "react";
import { screen } from "@testing-library/react";
import NotificationContainer from "../NotificationContainer";
import { renderWithProviders } from "../../test-utils";
import { addNotification } from "../../redux/notificationSlice";

jest.useFakeTimers();

test("auto-hides notifications", () => {
  const { store } = renderWithProviders(<NotificationContainer />);

  store.dispatch(addNotification({ message: "Hello", type: "success" }));
  expect(screen.getByText(/hello/i)).toBeInTheDocument();

  // Advance timers to trigger auto-remove (3s in your component)
  jest.advanceTimersByTime(3100);
  expect(screen.queryByText(/hello/i)).not.toBeInTheDocument();
});
