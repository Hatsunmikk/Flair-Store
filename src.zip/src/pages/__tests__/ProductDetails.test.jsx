import React from "react";
import { renderWithProviders } from "../../test-utils";
import { Routes, Route } from "react-router-dom";
import ProductDetails from "../ProductDetails";
import { screen } from "@testing-library/react";

test("ProductDetails renders for a given route", () => {
  renderWithProviders(
    <Routes>
      <Route path="/product/:id" element={<ProductDetails onAddToCart={() => {}} onAddToWishlist={() => {}} />} />
    </Routes>,
    { route: "/product/1" }
  );
  // Assert a generic thing that should exist (you can refine based on the component)
  expect(await screen.findByText(/product/i)).toBeInTheDocument();
});
