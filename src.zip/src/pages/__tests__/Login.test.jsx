import React from "react";
import { renderWithProviders } from "../../test-utils";
import Login from "../Login";
import { screen } from "@testing-library/react";

test("Login renders without crashing", () => {
  renderWithProviders(<Login />);
  expect(screen.getByRole("heading", { name: /login/i })).toBeInTheDocument();
  expect(screen.getByRole("button", { name: /login/i })).toBeInTheDocument();
});
