import React, { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function FAQSection() {
  const faqs = [
    {
      q: "How long does shipping take?",
      a: "Standard shipping usually takes 3-5 business days.",
    },
    {
      q: "Can I return a product?",
      a: "Yes, we accept free returns within 30 days of purchase.",
    },
    {
      q: "Do you offer customer support?",
      a: "Absolutely! We offer 24/7 customer support.",
    },
  ];

  const [openIdx, setOpenIdx] = useState(null);

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white p-4 rounded-lg shadow-sm border cursor-pointer"
              onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
            >
              <div className="flex justify-between items-center">
                <h3 className="font-medium text-gray-900">{faq.q}</h3>
                <ChevronDown
                  className={`w-5 h-5 text-gray-500 transition-transform ${
                    openIdx === idx ? "rotate-180" : ""
                  }`}
                />
              </div>
              {openIdx === idx && (
                <p className="mt-2 text-gray-600">{faq.a}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
