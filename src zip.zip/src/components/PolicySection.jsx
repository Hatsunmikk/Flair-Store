import React from "react";
import { ShieldCheck, Truck, Headset } from "lucide-react";

export default function PolicySection() {
  const policies = [
    {
      icon: <ShieldCheck className="w-8 h-8 text-pink-600" />,
      title: "Free Returns",
      desc: "Return any item for free within 30 days.",
    },
    {
      icon: <Truck className="w-8 h-8 text-pink-600" />,
      title: "Free Shipping",
      desc: "Enjoy free shipping on all orders.",
    },
    {
      icon: <Headset className="w-8 h-8 text-pink-600" />,
      title: "24/7 Support",
      desc: "We’re here to help anytime you need.",
    },
  ];

  return (
    <section className="py-12 bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
        {policies.map((p, idx) => (
          <div key={idx} className="flex flex-col items-center">
            {p.icon}
            <h3 className="mt-4 text-lg font-semibold text-gray-900">
              {p.title}
            </h3>
            <p className="mt-2 text-gray-600">{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
