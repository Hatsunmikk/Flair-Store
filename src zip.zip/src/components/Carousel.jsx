import React from "react";
import { motion } from "framer-motion";

export default function Carousel() {
  const slides = [
    { img: "https://via.placeholder.com/1200x400/FFB6C1/000?text=New+Arrivals", text: "Fresh Styles" },
    { img: "https://via.placeholder.com/1200x400/9370DB/000?text=Big+Sale", text: "Up to 50% Off" },
    { img: "https://via.placeholder.com/1200x400/87CEFA/000?text=Exclusive+Deals", text: "Shop Smart" },
  ];

  return (
    <div className="relative overflow-hidden h-64 sm:h-80 rounded-xl shadow-md mb-10">
      <motion.div
        className="flex h-full"
        animate={{ x: ["0%", "-100%", "-200%", "0%"] }}
        transition={{ repeat: Infinity, duration: 15, ease: "linear" }}
      >
        {slides.map((s, idx) => (
          <div key={idx} className="flex-shrink-0 w-full relative">
            <img src={s.img} alt={s.text} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <h2 className="text-2xl sm:text-3xl font-bold text-white">{s.text}</h2>
            </div>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
