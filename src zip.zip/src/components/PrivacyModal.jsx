import React, { useState } from "react";

export default function PrivacyModal({ title, content, triggerText }) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="text-sm text-pink-600 hover:underline"
      >
        {triggerText}
      </button>

      {open && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl max-w-lg w-full shadow-lg relative">
            <h2 className="text-xl font-bold mb-4">{title}</h2>
            <p className="text-gray-700 mb-6 whitespace-pre-line">{content}</p>
            <button
              onClick={() => setOpen(false)}
              className="px-4 py-2 bg-pink-600 text-white rounded hover:bg-pink-700"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
